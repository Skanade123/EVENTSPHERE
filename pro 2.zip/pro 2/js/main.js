
const prodContProd = document.querySelector("#products");
const prodContIndex = document.querySelector("#prod-index");
const prodContCart = document.querySelector("#prod-cart");

const prod1 = {
  imgSrc: "img/SCOvFRA.png",
  name: "SCOTTLAND VS FRANCE(PARIS)",
  price: 100,
};
const prod2 = {
  imgSrc: "img/ENGvsNEW.png",
  name: "ENGLAND VS NEW ZEALAND(LONDON)",
  price: 150,
};
const prod3 = {
  imgSrc: "img/ENGvsITA.png",
  name: "ENGLAND VS ITALY(NEW YORK)",
  price: 400,
};

const arr = [
  prod1,
  prod2,
  prod3,
];

const displayProducts = () => {
  for (let i = 0; i < arr.length; i++) {
    let imgSrc = arr[i].imgSrc;
    let name = arr[i].name;
    let price = arr[i].price;
    const check = "prod";
    createProd(imgSrc, name, price, check);
  }
};

const displayProdIndex = () => {
  for (let i = 0; i < 3; i++) {

    let imgSrc = arr[i].imgSrc;
    let name = arr[i].name;
    let price = arr[i].price;
    const check = "index";
    createProd(imgSrc, name, price, check);
  }
};

const displayProdCart = () => {
  for (let i = 0; i < 2; i++) {
    let imgSrc = arr[i].imgSrc;
    let name = arr[i].name;
    let price = arr[i].price;
    createCartProd(imgSrc, name, price);
  }
};

const createProd = (imgSrc, name, price, check) => {
  let divProd = document.createElement("div");
  let imgProd = document.createElement("img");
  let nameProd = document.createElement("h4");
  let priceProd = document.createElement("p");
  let buttonProd = document.createElement("button");
  let divOverlay = document.createElement("div");
  let prodDesc = document.createElement("p");


  imgProd.src = imgSrc;
  nameProd.innerText = name;
  priceProd.innerText = "$" + price;
  buttonProd.innerText = "Add to cart";
  prodDesc.innerText =
    "The Six Nations Championship is an annual international men's rugby union competition between the teams of England, France, Ireland, Italy, Scotland and Wales. It is also the oldest sports tournament ever between Home Nations.";
 

  priceProd.className = "price";
  buttonProd.className = "atc-btn";
 
  divOverlay.className = "overlay";
  prodDesc.className = "description";
  divProd.className = "img-products";

  divOverlay.appendChild(prodDesc);
  
  divOverlay.appendChild(buttonProd);
  divProd.appendChild(imgProd);
  divProd.appendChild(nameProd);
  divProd.appendChild(priceProd);
  divProd.appendChild(divOverlay);
  if (check === "prod") {
    prodContProd.appendChild(divProd);
  } else if (check === "index") {
    prodContIndex.appendChild(divProd);
  }
};




