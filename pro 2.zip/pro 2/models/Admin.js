const mongoose = require('mongoose');


module.exports = Event; const adminSchema = new mongoose.Schema({
    AdminId: {
        type: Number,
        required: true,
        unique: true
    },
    FirstName: {
        type: String,
        required: true
    },
    LastName: {
        type: String,
        required: true
    },
    Password: {
        type: String,
        required: true
    },
    Phone: {
        type: String,
        required: true
    },
    Email: {
        type: String,
        required: true,
        unique: true
    }
});

const Admin = mongoose.model('Admin', adminSchema);

module.exports = Admin;