const mongoose = require('mongoose');



const bookingSchema = new mongoose.Schema({
    BookingId: {
        type: Number,
        required: true,
        unique: true
    },
    UserId: {
        type: Number,
        required: true
    },
    EventId: {
        type: Number,
        required: true
    },
    BookingTime: {
        type: Date,
        required: true
    },
    Price: {
        type: Number,
        required: true
    },
    NoOfTickets: {
        type: Number,
        required: true
    },
    VenueId: {
        type: Number,
        required: true
    }
});

const Booking = mongoose.model('Booking', bookingSchema);

module.exports = Booking;