const mongoose = require('mongoose');



const cartSchema = new mongoose.Schema({
    CartId: {
        type: Number,
        required: true,
        unique: true
    },
    EventId: {
        type: Number,
        required: true,
        unique: true
    },
    UserId: {
        type: Number,
        required: true,
        unique: true
    },
    Price: {
        type: Number,
        required: true
    }
});

const Cart = mongoose.model('Cart', cartSchema);

module.exports = Cart;