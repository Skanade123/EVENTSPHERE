const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema({
    EventId: {
        type: Number,
        required: true,
        unique: true
    },
    EventName: {
        type: String,
        required: true
    },
    EventDescription: {
        type: String,
        required: true
    },
    EventTicketPrice: {
        type: Number,
        required: true
    },
    VenueId: {
        type: Number,
        required: true
    },
    EventTime: {
        type: Date,
        required: true
    }
});

const Event = mongoose.model('Event', eventSchema);

module.exports = Event;