const mongoose = require('mongoose');

const recommendationSchema = new mongoose.Schema({
    EventId: {
        type: Number,
        required: true,
        unique: true
    },
    Count: {
        type: Number,
        required: true
    }
});

const Recommendation = mongoose.model('Recommendation', recommendationSchema);

module.exports = Recommendation;