const mongoose = require('mongoose');


const venueSchema = new mongoose.Schema({
    VenueId: {
        type: Number,
        required: true,
        unique: true
    },
    Name: {
        type: String,
        required: true
    },
    City: {
        type: String,
        required: true
    },
    State: {
        type: String,
        required: true
    },
    Country: {
        type: String,
        required: true
    }
});


const Venue = mongoose.model('Venue', venueSchema);

module.exports = Venue;