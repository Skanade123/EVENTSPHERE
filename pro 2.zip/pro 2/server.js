const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');
const mongoose = require('mongoose');
const ejs = require('ejs');
const session = require('express-session');


app.set('view engine', 'ejs');






const User = require('./models/User');
const Event = require('./models/Event');
const Admin = require('./models/Admin');
const Booking = require('./models/Booking');
const Cart = require('./models/Cart');
const Recommendation = require('./models/Recommendation');
const Venue = require('./models/Venue');



// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('icons'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({ secret: ' thisisasecrettobeshared' }));


// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/Eventeee', { useNewUrlParser: true, useUnifiedTopology: true });


const db = mongoose.connection;


// Routes
app.get('/', async (req, res) => {
    const topEvents = await Recommendation.find().sort({ count: -1 }).limit(3);

    db.createView("eventNames", "Event", [
        {
            $lookup:
            {
                from: "topEvents",
                localField: "EventId",
                foreignField: "EventId",
                as: "tempeventnames"
            }
        },
        {
            $project:
            {
                _id: 0
            }
        },
        { $unwind: "$price" }
    ])
    console.log(topEvents);
    console.log(eventNames);
    res.render('homepage.ejs', { data: topEvents });
});

app.get('/loginpage', (req, res) => {
    if (session.userId === null) {
        res.redirect('/');
    }
    res.render('loginpage.ejs');
});

app.get('/prof', async (req, res) => {
    if (session.userId === null) {
        res.redirect('/');
    }
    const userId = session.userId;
    console.log(userId);
    const user = await User.findOne({ UserId: userId });
    console.log(user);
    //const bookings = await Booking.find({UserId:userId});
    const bookings = await Booking.find({ UserId: userId }).exec();
    console.log(bookings);

    res.render('profile.ejs', { user: user, bookings: bookings });
});

app.get('/cart', async (req, res) => {
    if (session.userId === null) {
        res.redirect('/');
    }
    res.render('cart.ejs');
});

app.get('/register', async (req, res) => {
    if (session.userId === null) {
        res.redirect('/');
    }
    res.render('registrationform.ejs');

});


app.get('/eventregistration', async (req, res) => {
    if (session.userId === null) {
        res.redirect('/');
    }
    res.render('eventregistration.ejs');

});



app.get('/proceedtocheckout', async (req, res) => {
    if (session.userId === null) {
        res.redirect('/');
    }

    res.redirect('/cart');

});

app.get('/logout', async (req, res) => {
    session.userId = null;
    console.log(session.userId);
    res.redirect('/');

});


app.post('/registerevent', async (req, res) => {
    if (session.userId === null) {
        res.redirect('/');
    }
    const { eventName, eventDescription, ticket, venue, time } = req.body;
    console.log(eventName, eventDescription, ticket, venue, time);
    try {
        const event = new Event({
            EventId: Math.floor(Math.random() % 50 + Math.random() % 50 + 51 + 51),
            EventName: eventName,
            EventDescription: eventDescription,
            EventTicketPrice: ticket,
            VenueId: venue,
            EventTime: time
        });
        await event.save();
        res.redirect('/loginpage');
    } catch (error) {
        console.log(error);
        res.status(400).send('Registration failed!');
    }
});

// Validate password complexity function
function validatePassword(password) {
    return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=. *[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(password);
}

// Validate username uniqueness function
async function isUsernameUnique(username) {
    const user = await User.findOne({ username });
    return !user;
}


app.post('/register', async (req, res) => {
    const { firstName, lastName, username, email, password, address, phone } = req.body;
    // Regular expression for password validation
    const passwordRegex = /^(?=.\d)(?=.[!@#$%^&])(?=.[a-zA-Z]).{8,}$/;

    // Regular expression for email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    try {
        // Check if the password meets complexity requirements
        if (!validatePassword(password)) {
            return res.status(400).send('Password must be at least 8 characters long and contain at least one special symbol, one digit, and one letter.');
        }

        // Check if the username is unique
        const isUsernameUnique1 = await isUsernameUnique(username);
        if (!isUsernameUnique1) {
            return res.status(400).send('Username already exists.');
        }

        // Check if the email format is valid
        if (!emailRegex.test(email)) {
            return res.status(400).send('Invalid email format.');
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        //const count = User.countDocuments()
        const user = new User({
            UserId: Math.floor(Math.random() * (50 - 1 + 1)) + 1,
            FirstName: firstName,
            LastName: lastName,
            UserName: username,
            Password: hashedPassword,
            Address: address,
            Phone: phone,
            Email: email
        });
        await user.save();
        res.redirect('/');


    } catch (error) {
        console.log(error);
        res.status(400).send('Registration failed!');
    }
});




app.post('/login', async (req, res) => {
    const { username, password } = req.body;

    try {

        //Check if the user exists in the database
        const user = await User.findOne({ UserName: username });

        if (user) {
            console.log(user);
            const isPasswordValid = await bcrypt.compare(password, user.Password);

            if (isPasswordValid) {
                console.log("logged in ");
                session.userId = user.UserId;
                console.log(session.userId);
                res.redirect('/loginpage');
            } else {
                console.log("pass fail");
                res.redirect('/');
            }
        } else {
            console.log("user not");
            res.redirect('/');
        }

        // If username and password are correct, redirect to the home page or a dashboard


    } catch (error) {
        console.log(error);
        res.status(500).send('Internal Server Error');
    }
});



app.get('/search', (req, res) => {

    const query = req.query.query;

    // Perform MongoDB search query using promises

    Event.find({ name: { $regex: query, $options: 'i' } })

        .then(items => {

            res.render('searchresults.ejs', { items: items }); // Render the EJS template with search results

        })

        .catch(err => {

            console.error(err);

            res.status(500).send('Error searching items');

        });

});

app.listen(3000, () => {
    console.log('Server is running on port 3000');
});